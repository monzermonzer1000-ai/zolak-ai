# Zolak AI release rules

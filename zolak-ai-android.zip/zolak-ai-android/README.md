# زولك AI — Android

نسخة Android مرتبطة بالموقع الحالي لـ زولك AI.

## البناء

افتح المجلد في Android Studio ثم اعمل Sync و Build > Generate Signed App Bundle.

أو من GitHub Actions شغّل **Build Zolak AI Android** للحصول على AAB غير موقّع.

## مهم قبل Google Play

- غيّر `applicationId` إذا أردت معرّفاً مختلفاً.
- أنشئ Upload/Release keystore خاص بك ولا تضعه داخل GitHub.
- أضف signing secrets إلى GitHub إذا أردت بناء AAB موقّع تلقائياً.
- راجع رابط الموقع في `MainActivity.java` إذا تغيّر الاستضافة.

## الإصدار الحالي

Version name: 1.0.0
Version code: 1
Application ID: com.zolak.ai
